#include <stddef.h>

#define RET_OK   0     // success
#define RET_KO   1     // generic failure / error
#define RET_ERR_INVALID_ARG 2  // invalid argument
#define RET_ERR_TIMEOUT     3  // timeout occurred
#define RET_ERR_IO          4  // input/output error
#define RET_ERR_NOT_FOUND   5  // resource not found
#define RET_ERR_UNSUPPORTED 6  // unsupported operation

#define UNUSED(x) (void)(x)  // macro to suppress unused variable warnings
#define UNUSED_INT 1
#define UNUSED_BOOL false
#define UNUSED_STR "unused" // macro to suppress unused string warnings
#define UNUSED_PTR NULL // macro to suppress unused pointer warnings