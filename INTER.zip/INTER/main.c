// SPDX-License-Identifier: LicenseRef-PATO-ESEO

/**
 * @file main.c
 * @brief Source file for the main module.
 *
 * @author
 * ForcePushRebels – PATO Project (collective contributor)  
 * Uriel Fodong <uriel.fodong@reseau.eseo.fr> (individual contributor)
 *
 * @version 0.0.0
 *
 * @copyright
 * © 2025 ESEO – All rights reserved.
 *
 * @par License
 * PATO ESEO License (see LICENSE.md)
 */

#include "main.h"

int main(int argc, char *argv[]) {
	
	(void)argc; // Avoid unused parameter warning
	(void)argv; // Avoid unused parameter warning
	
	StrategyManager *strategyManager = create();
	
	/*
		Logic to implement here...
	*/
	
	delete(strategyManager);
	
	return EXIT_FAILURE;
}