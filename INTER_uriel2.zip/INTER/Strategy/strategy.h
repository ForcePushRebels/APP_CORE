#ifndef __STRATEGY_H__
#define __STRATEGY_H__

void STRATEGY__prepare(int (* map_ptr)[10]);

void STRATEGY__execute(int (*map_ptr)[2]);

void strategy1();
void strategy2();
void strategy3();

#endif /* __STRATEGY_H__ */