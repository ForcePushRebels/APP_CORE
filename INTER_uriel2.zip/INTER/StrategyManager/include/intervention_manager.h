// SPDX-License-Identifier: LicenseRef-PATO-ESEO

/**
 * @file intervention_manager.h
 * @brief Header file for the Intervention Manager module.
 * 
 * @details
 * This file is part of the PATO project developed by ForcePushRebels.
 * The project was coordinated by Mr. Jérôme DELATOUR, in collaboration with
 * faculty of the Embedded Software and Cybersecurity (LEC) option at ESEO.
 * 
 * It constitutes a collective work as per Article L113-2 of the French
 * Intellectual Property Code.
 *
 * Usage is restricted to educational purposes within ESEO. Redistribution,
 * public use, or commercial exploitation without prior written consent is prohibited.
 *
 * The content is provided "as is," without any warranty or guarantee.
 *
 * @author
 * ForcePushRebels – PATO Project (collective contributor)
 * Uriel Fodong <uriel.fodong@reseau.eseo.fr> (individual contributor)
 * 
 * @version 0.1.0
 *
 * @copyright
 * © 2025 ESEO – All rights reserved.
 *
 * @par License
 * PATO ESEO License (see LICENSE.md)
 */

#ifndef __INTERVENTION_MANAGER_H__
#define __INTERVENTION_MANAGER_H__

#include <stdbool.h> // For boolean pseudo-type

#include <time.h> // For timer management

#include "../../symbols/geometry.h"

#define V(MAJ, MIN, PATCH) ((MAJ)*10000 + (MIN)*100 + (PATCH)) // Macro to define version numbers
#define INTERVENTION_MANAGER_API_VERSION 	V(0, 1, 0) // current header API version

typedef struct intervention_manager_s InterventionManager; // To force using the API

/* Public methods */

	// Constructor and destructor

InterventionManager * intervention_manager__create(void);

void intervention_manager__delete(InterventionManager *);

	// Strategy management

void intervention_manager__askStrat(InterventionManager *);

void intervention_manager__giveIDStrategieToFollow(InterventionManager *, int);

	// Movement control

void intervention_manager__startMove(InterventionManager *);

void intervention_manager__endMove(InterventionManager *);

	// External alert

bool intervention_manager__alertWallNear(InterventionManager *);

void intervention_manager__alertEndConditionReach(InterventionManager *);

	// Status management

int intervention_manager__getStatus(InterventionManager *);

void intervention_manager__reportStatus(InterventionManager *, MoveReason);

	// Manual interlock
	
void intervention_manager__interlockManuMode(InterventionManager *);
 
	// Points selection
void intervention_manager__sendPointsSelection(InterventionManager *self, Position *);

	// Intervention control
void intervention_manager__startInter(InterventionManager *self);

void intervention_manager__stopInter(InterventionManager *self);

	// Time management
int intervention_manager__getTimeInter(InterventionManager *self);

#endif /* __INTERVENTION_MANAGER_H__ */